import pygame
import math
import threading

class snappy:
    framerate = 20
    frameperiod = 1000.0/framerate
    size = width, height = 480, 360+33
    screen = None
    running = 0
    allsprites = None
    frameUpdated = threading.Condition()
    myEvents = []
    sp_font = None
    clock = pygame.time.Clock()

#sec class - secondary variables - all these should go away

class sec:
    flag = None
    flag_rect = None
    flagon = None

def start():
    pygame.init()
    snappy.screen = pygame.display.set_mode(snappy.size, pygame.DOUBLEBUF)

    topbar_rect = pygame.Rect(0,0,480,33)
    topbar_surf = pygame.Surface((480,33))

    sec.stage_rect = pygame.Rect(0,33,480,360)
    sec.stage_surf = pygame.Surface((480,360))
    sec.stage_back = pygame.Surface((480,360))
    sec.stage_back.fill((255,255,255))
    sec.stage_surf.blit(sec.stage_back, (0,0))

    background = pygame.Surface(snappy.screen.get_size())
    background = background.convert()
    topbar_surf.fill((149,154,159))
    pygame.draw.line(topbar_surf, (110, 114,118), (0,25), (479,25))
    pygame.draw.line(topbar_surf, (182,185,186), (0,26), (479,26))
    pygame.draw.line(topbar_surf, (207,209,212), (0,27), (479,27))
    pygame.draw.line(topbar_surf, (169,172,175), (0,28), (479,28))
    pygame.draw.line(topbar_surf, (133,135,137), (0,29), (479,29))
    pygame.draw.line(topbar_surf, (125,125,126), (0,30), (479,30))
    pygame.draw.line(topbar_surf, (189,189,190), (0,31), (479,31))
    pygame.draw.line(topbar_surf, (238,238,239), (0,32), (479,32))

    sec.flag = pygame.image.load("FlagDull.png")
    topbar_surf.blit(sec.flag, (404,5))
    sec.flag_rect = sec.flag.get_rect().move((404,5))
    sec.flagon = pygame.image.load("FlagBright.png")

    pause = pygame.image.load("PauseDull.png")
    topbar_surf.blit(pause, (428,5))
    stop = pygame.image.load("StopDull.png")
    topbar_surf.blit(stop, (450,5))

    background.blit(topbar_surf, (0,0))
    background.blit(sec.stage_surf, sec.stage_rect)

    snappy.screen.blit(background, (0,0))
    pygame.display.flip()
    pygame.event.pump()

    snappy.allsprites = pygame.sprite.LayeredUpdates()
    snappy.sp_font = pygame.font.Font(None, 20)
    startgame()

def stop():
    snappy.running = 0

def breakLines(text):
    lines = []
    words = text.split(' ')
    currline = ""
    
class Costume:
    def __init__(self, filename):
        self.picture = pygame.image.load(filename)
        self.center = self.picture.get_rect().center


class Sprite(pygame.sprite.Sprite):
    def __init__(self, costumeFile, location=(0,0)):
        pygame.sprite.Sprite.__init__(self)
        self.location = location
        self.size = 100
        self.direction = 90
        self.redraw = True
        self.rotationStyle = 1
        self.costumes = [ Costume(costumeFile) ]
        self.costumeNames = { costumeFile: 0 }
        self._setcostume_internal(0)
        self.movingToward = None
        self.arrivalTime = None
        self.speechBubble = None
        self.speechExpire = 0
        snappy.allsprites.add(self)

    def _setimage(self):
        basepic = self.costumes[self.costume_num].picture
        if (self.size != 100):
            neww = int(round((self.size/100.0)*basepic.get_rect().width))
            newh = int(round((self.size/100.0)*basepic.get_rect().height))
            basepic = pygame.transform.scale(basepic, (neww, newh))
        if self.rotationStyle == 1:
            oldCenter = self.rect.center
            self.image = pygame.transform.rotate(basepic, 90-self.direction)
            self.rect = self.image.get_rect()
            self.rect.center = oldCenter
        elif self.rotationStyle == 2:
            normalized = self.direction
            if (normalized < 0): normalized = 360*(1+int(-normalized)/360) + normalized
            elif normalized >= 360: normalized = normalized - 360*(int(normalized)/360)
            if normalized <= 180:
                self.image = basepic
            else:
                self.image = pygame.transform.flip(basepic, True, False)
        else:
            oldCenter = self.rect.center
            self.image = basepic
            self.rect = self.image.get_rect()
            self.rect.center = oldCenter
        self.redraw = False
        
    def _setcostume_internal(self, cnum):
        if (cnum >= 0) and (cnum < len(self.costumes)):
            self.costume_num = cnum
            self.image = self.costumes[cnum].picture
            self.rect = self.image.get_rect()
            self.center = self.costumes[cnum].center
            self._move_internal(self.location)
        
    def _move_internal(self, pos):
        self.location = pos;
        self.rect.x = 240+pos[0]-self.center[0]
        self.rect.y = 180-pos[1]-self.center[1]

    def loadCostume(self, fileName):
        newCostume = Costume(fileName)
        self.costumes.append(newCostume)
        self.costumeNames[fileName] = len(self.costumes)-1;
        
    def switchToCostume(self, number):
        self._setcostume_internal(number)
        self.redraw = True
        
    def move(self, steps):
        deltax = int(round(steps*math.sin(math.radians(self.direction))))
        deltay = int(round(steps*math.cos(math.radians(self.direction))))
        self.goTo((self.location[0]+deltax,self.location[1]+deltay))

    def turnCW(self, degrees):
        pointInDirection(self.direction+degrees)

    def turnCCW(self,degrees):
        pointInDirection(self.direction-degrees)
        
    def pointInDirection(self, dir):
        if dir != self.direction:
            self.direction = dir
            self.redraw = True
        if snappy.running:
            with snappy.frameUpdated: snappy.frameUpdated.wait()

    def setRotStyle(self, style):
        if (style != self.rotationStyle):
            self.rotationStyle = style
            self.redraw = True
            
    def goTo(self, pos):
        self._move_internal(pos)
        with snappy.frameUpdated: snappy.frameUpdated.wait()
        
    def glideForTo(self, duration, to):
        self.movingToward = to
        self.arrivalTime = pygame.time.get_ticks() + duration*1000
        while self.movingToward != None:
            with snappy.frameUpdated: snappy.frameUpdated.wait()

    def changeXBy(self, deltaX):
        self.goTo((self.location[0]+deltaX, self.location[1]))

    def setXTo(self, newX):
        self.goTo((newX,self.location[1]))

    def changeYBy(self, deltaY):
        self.goTo((self.location[0], self.location[1]+deltaY))

    def setYTo(self, newY):
        self.goTo((location[0], newY))

    def setSize(self, size):
        self.size = size
        self.redraw = True
        if snappy.running:
            with snappy.frameUpdated: snappy.frameUpdated.wait()        

    def say(self, text):
        self.speechBubble = speechbubble(text)
        self.speechExpire = 0

    def sayFor(self, text, duration):
        self.speechBubble = speechbubble(text)
        self.speechExpire = pygame.time.get_ticks()+duration*1000
        while self.speechBubble != None:
            with snappy.frameUpdated: snappy.frameUpdated.wait()

    def wait(self, duration):
        expire = pygame.time.get_ticks()+duration*1000
        while expire > pygame.time.get_ticks():
            with snappy.frameUpdated: snappy.frameUpdated.wait()
        
    def update(self):
        currTime = pygame.time.get_ticks()
        if self.movingToward != None:
            if (currTime+snappy.frameperiod >= self.arrivalTime):
                self._move_internal(self.movingToward)
                self.movingToward = None
            else:
                timespan = self.arrivalTime-currTime
                fraction = snappy.frameperiod/timespan
                self._move_internal((self.location[0]+(self.movingToward[0]-self.location[0])*fraction,
                                self.location[1]+(self.movingToward[1]-self.location[1])*fraction))
        if self.redraw:
            self._setimage()
        if self.speechBubble != None and self.speechExpire > 0 and self.speechExpire < currTime:
            self.speechBubble = None
        if self.speechBubble != None:
            self.speechBubble.drawFor(sec.stage_surf, self)


def textToLines(font, text, maxWidth=320):
    lines = []
    start=0
    lstart = 0
    end=0
    nend=0
    while start < len(text):
        # start is 1st char of next line ; nend is next non-space to consider
        while (nend < len(text) and text[nend]!=' '): nend += 1
        # now nend is past next word-to-consider
        nstart = nend
        while nstart < len(text) and text[nstart] == ' ': nstart += 1
        w = font.size(text[start:nend])[0]
        if w > maxWidth:
            if (start == end):
                lines.append(text[start:nend])
                start = nstart
            else:
                lines.append(text[start:end])
                start = lstart
        if nstart == len(text):
            lines.append(text[start:nend])
            start = nstart
        end = nend
        lstart = nstart
        nend = nstart
    return lines


def renderText(font, text, justify=0, maxWidth=320):
    lines = textToLines(font, text, maxWidth)
    s = [ font.render(lines[i], True, (0,0,0)) for i in range(len(lines)) ]
    width = max([s[i].get_width() for i in range(len(s))])
    height = font.get_linesize()*len(s)
    ret = pygame.Surface((width,height))
    ret.fill((255,255,255))
    for i in range(len(s)):
        if justify == 0: x=0
        elif justify == 1: x=int((width-s[i].get_width())/2)
        else: x=width-s[i].get_width()
        ret.blit(s[i], (x, i*font.get_linesize()))
    return ret

def updateall():
    sec.stage_surf.blit(sec.stage_back, (0,0))
    snappy.allsprites.update()
    snappy.allsprites.draw(sec.stage_surf)
    snappy.screen.blit(sec.stage_surf, sec.stage_rect)
    pygame.display.flip()

# make this a class, and init with icons and rect - could be a sprite w/update?
def activeicon(activeflag, iconoff, iconon, mousepos, rect):
    overicon = rect.collidepoint(mousepos)
    if not activeflag and overicon:
        activeflag = True
        snappy.screen.blit(iconon, rect)
    elif activeflag and not overicon:
        activeflag = False
        snappy.screen.blit(iconoff, rect)
    return activeflag

eventHandlers = {}

def registerGeneric(name, function):
    global eventHandlers
    if name in eventHandlers:
        eventHandlers[name].append(function)
    else:
        eventHandlers[name] = [ function ]

def startOnReceiving(signalName):
    return lambda fn : registerGeneric('b-'+signalName, fn)

def startOnKey(key):
    return lambda fn : registerGeneric('k-'+key, fn)
    
def dohandlers(name):
    global eventHandlers
    if name in eventHandlers:
        for h in eventHandlers[name]:
            t = threading.Thread(target=h)
            t.daemon = True
            t.start()
    else:
        print('unknown event: '+name)
        

def broadcast(signalName):
    snappy.myEvents.append('b-'+signalName)

def dogame():
    snappy.running = 1
    flagactive=False
    while snappy.running:
        eList = pygame.event.get()
        for e in eList:
            if e.type == pygame.KEYDOWN:
                if e.key >=0 and e.key < 256:
                    dohandlers('k-'+chr(e.key))
        for e in snappy.myEvents:
            dohandlers(e)
        snappy.myEvents = []
        mousepos = pygame.mouse.get_pos()
        flagactive = activeicon(flagactive, sec.flag, sec.flagon, mousepos, sec.flag_rect)
        updateall()
        with snappy.frameUpdated: snappy.frameUpdated.notifyAll()
        snappy.clock.tick(snappy.framerate)

def startgame():
    t = threading.Thread(target=dogame)
    t.daemon = True
    t.start()
    return t

pts_ul = [ (7,0), (5,0), (3,1), (1,3), (0,5), (0,7), (4,7), (5,5), (7,4)]
pts_sp = [(22, 0), (12, 15), (37, 0), (31, 0), (24, 3), (26, 0)]
red = (255,0,0)
white = (255,255,255)

def clear():
    sec.stage_back.fill(white)

def outline(color, rect, toRight=True):
    # for now fixed padding: 3 at top and bottom, 5 on sides
    padl, padt, padr, padb = 5, 3, 5, 3
    bubble_sz = (rect.width+10+padl+padr, rect.height+10+padt+padb)
    if bubble_sz[0] < 52: bubble_sz = (52, bubble_sz[1])
    surf = pygame.Surface((bubble_sz[0],bubble_sz[1]+15))
    surf.fill((255,255,255))
    pygame.draw.polygon(surf, color, pts_ul, 0)
    surf.fill(color, pygame.Rect(8, 0, bubble_sz[0]-16, 5))
    pygame.draw.polygon(surf, color, map( lambda(p): (bubble_sz[0]-1-p[0], p[1]), pts_ul), 0)
    surf.fill(color, pygame.Rect(bubble_sz[0]-5, 8, 5, bubble_sz[1]-16))
    pygame.draw.polygon(surf, color, map( lambda(p): (bubble_sz[0]-1-p[0], bubble_sz[1]-1-p[1]), pts_ul), 0)
    # bottom for speech bubble
    if toRight:
        surf.fill(color, pygame.Rect(8, bubble_sz[1]-5, 14, 5))
        pygame.draw.polygon(surf, color, map( lambda(p): (p[0], bubble_sz[1]-5+p[1]), pts_sp), 0)
        surf.fill(color, pygame.Rect(32, bubble_sz[1]-5, bubble_sz[0]-40, 5))
    else:
        surf.fill(color, pygame.Rect(8, bubble_sz[1]-5, bubble_sz[0]-40, 5))
        pygame.draw.polygon(surf, color, map( lambda(p): (bubble_sz[0]-1-p[0], bubble_sz[1]-5+p[1]), pts_sp), 0)
        surf.fill(color, pygame.Rect(bubble_sz[0]-22, bubble_sz[1]-5, 14, 5))
    # end of speech bubble bottom
    pygame.draw.polygon(surf, color, map( lambda(p): (p[0], bubble_sz[1]-1-p[1]), pts_ul), 0)
    surf.fill(color, pygame.Rect(0, 8, 5, bubble_sz[1]-16))
    return surf

def speech(text):
    sp_surf = renderText(snappy.sp_font, text, 1, 160)
    bubble_surf = outline((140,140,140),sp_surf.get_rect())
    bubble_surf.blit(sp_surf, ((bubble_surf.get_width()-sp_surf.get_width())/2,8))
    sec.stage_back.blit(bubble_surf, (10,10))

class speechbubble:
    def __init__(self, text):
        self.text = text
        self.textsurf = renderText(snappy.sp_font, text, 1, 130)
        self.bubble_toright = outline((190,190,190),self.textsurf.get_rect(),True)
        self.bubble_toright.blit(self.textsurf, ((self.bubble_toright.get_width()-self.textsurf.get_width())/2, 8))
        self.bubble_toleft = None
        self.width = self.bubble_toright.get_rect().width
        
    def drawFor(self, surf, sprite):
        x = sprite.rect.centerx
        y = sprite.rect.top - self.bubble_toright.get_rect().height
        if (y < 0): y = 0
        if (x + self.width) <= 480:
            surf.blit(self.bubble_toright, (x,y))
        else:
            if self.bubble_toleft == None:
                self.bubble_toleft = outline((190,190,190),self.textsurf.get_rect(),False)
                self.bubble_toleft.blit(self.textsurf, ((self.bubble_toleft.get_width()-self.textsurf.get_width())/2, 8))
            surf.blit(self.bubble_toleft, (x-self.width,y))


# TODO: Make sprites active so they can be clicked on, with greenflag etc.
# being just other active sprites

# TODO: Better thread management




