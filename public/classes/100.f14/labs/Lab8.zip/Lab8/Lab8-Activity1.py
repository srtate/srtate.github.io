import snappy

snappy.start()
alonzo = snappy.Sprite('alonzo.gif', (-70,0))
dragon = snappy.Sprite('dragon1-a.png', (120,0))
dragon.setRotStyle(2)
dragon.pointInDirection(-90)
dragon.loadCostume('dragon1-b.png')

@snappy.startOnReceiving('Go')
def DragonScript1():
    sprite = dragon
    sprite.goTo((120,2))
    while True:
        sprite.glideForTo(0.5, (120,12))
        sprite.glideForTo(0.5, (120,2))

@snappy.startOnReceiving('Go')
def DragonScript2():
    sprite = dragon
    sprite.sayFor("Hello!", 1)
    sprite.sayFor("I'm a dragon", 1)
    snappy.broadcast('Dragon Done')

@snappy.startOnReceiving('Alonzo Done')
def DragonScript3():
    sprite = dragon
    sprite.sayFor("Want to see me breathe fire?", 1)
    sprite.switchToCostume(1)
    sprite.wait(1)
    sprite.switchToCostume(0)
    sprite.sayFor("Isn't that cool?", 1)
    snappy.stop()

@snappy.startOnKey('w')
def AlonzoScript1():
    sprite=alonzo
    sprite.changeYBy(10)

@snappy.startOnReceiving('Dragon Done')
def AlonzoScript2():
    sprite=alonzo
    sprite.sayFor("Hi, I'm Alonzo", 1)
    sprite.sayFor("I'm a...  well, I'm not sure", 1)
    snappy.broadcast('Alonzo Done')

