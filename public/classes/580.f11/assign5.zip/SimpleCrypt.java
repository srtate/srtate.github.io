import java.io.*;

class SimpleCrypt {

    // =================================================================
    // Note:  This is the "rand" function from ANSI C.  Implementation provided
    // here to insure everyone is using the same rand() function!

    static int state = 1;

    static void mysrand(int seed) {
	state = seed;
    }

    static int myrand() {
	state = state * 1103515245 + 12345;
	return (state >> 16) & 0x7fff;
    }

    // =================================================================

    public static void main(String argv[]) {
	int secretkey = 671341365;  /* This is the secret key!!! */
	FileInputStream infile = null;

	if (argv.length != 1) {
	    System.err.println("Usage: java SimpleCrypt inputfile");
	    System.exit(1);
	}

	try {
	    infile = new FileInputStream(argv[0]);
	} catch (FileNotFoundException e) {
	    System.err.println("Couldn't open input file ("+argv[0]+")");
	    return;
	}

	// Note for students: This is really a silly way to do this if
	// you're just interested in a simple encrypt/decrypt
	// operation using a pseudorandom stream.  There's no reason
	// to read in the whole file before processing, since in can
	// be done in a char-by-char (or block-by-block) streaming
	// manner.  The only reason the code is like this is because
	// you might find it useful to do it this way for a brute
	// force attack (hint, hint, ...).

	int filelen = 0;
	try {
	    filelen = infile.available();  // Length of data to encrypt/decrypt
	} catch (IOException e) {
	    System.err.println("Error determining available input: "+e);
	    return;
	}

	byte data[] = new byte[filelen];
	try {
	    infile.read(data);
	} catch (IOException e) {
	    System.err.println("Error reading: " + e);
	    return;
	}

	mysrand(secretkey);
	for (int i=0; i<filelen; i++)
	    data[i] ^= (myrand() & 0xff);

	System.out.write(data, 0, data.length);
    }
}
