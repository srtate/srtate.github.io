#include <stdio.h>
#include <stdlib.h>

/* ================================================================= */
/* Note:  This is the "rand" function from ANSI C.  Implementation provided */
/* here to insure everyone is using the same rand() function! */

int state = 1;

void mysrand(int seed)
{
    state = seed;
}


int myrand()
{
    state = state * 1103515245 + 12345;
    return (state >> 16) & 0x7fff;
}

/* ================================================================= */

int main(int argc, char *argv[])
{
    int secretkey = 671341365;  /* This is the secret key!!! */
    FILE *infile;  /* File with input data (output written to stdout) */
    long filelen;  /* Length of data to encrypt/decrypt */
    char *data;    /* To store the file contents */
    int i;

    if (argc != 2) {
	fprintf(stderr, "Usage: %s inputfile\n", argv[0]);
	exit(1);
    }

    if ((infile=fopen(argv[1], "rb")) == NULL) {
	fprintf(stderr, "Couldn't open input file (%s)\n", argv[1]);
	exit(1);
    }

/* 
 * Note for students:  This is really a silly way to do this if you're
 * just interested in a simple encrypt/decrypt operation using a pseudorandom
 * stream.  There's no reason to read in the whole file before processing,
 * since in can be done in a char-by-char (or block-by-block) streaming
 * manner.  The only reason the code is like this is because you might
 * find it useful to do it this way for a brute force attack (hint, hint, ...).
 */

    if ((fseek(infile, 0L, SEEK_END) == -1) ||
	((filelen=ftell(infile)) == -1) ||
	(fseek(infile, 0L, SEEK_SET) == -1)) {
	fprintf(stderr, "Couldn't determine the size of the input!\n");
	exit(1);
    }

    if ((data=malloc(filelen)) == NULL) {
	fprintf(stderr, "Couldn't allocate memory for file.\n");
	exit(1);
    }

    fread(data, 1, filelen, infile);

    mysrand(secretkey);
    for (i=0; i<filelen; i++)
	data[i] ^= (myrand() & 0xff);

    fwrite(data, 1, filelen, stdout);

    return 0;
}
